//
// Created by Rafael Szuminski on 2/6/20.
//

#ifndef HW02_BMI_H
#define HW02_BMI_H


float male_calc(float init_b_weight, float init_waist_m);
float female_calc(float init_b_weight, float init_wrist_m, float init_waist_m, float init_hip_m, float init_forearm_m );


#endif //HW02_BMI_H
