//
// Created by Rafael Szuminski on 1/23/20.
//

#ifndef HW01_PL_H
#define HW01_PL_H


#include <string>

int decoder(char value);
std::vector<int> str_to_int_decoder(std::string value);
std::string int_to_phonenum(std::vector<int> val );

#endif //HW01_PL_H
